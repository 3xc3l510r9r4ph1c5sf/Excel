<div class="front_page_section front_page_section_contacts<?php
	$algenix_scheme = algenix_get_theme_option( 'front_page_contacts_scheme' );
	if ( ! empty( $algenix_scheme ) && ! algenix_is_inherit( $algenix_scheme ) ) {
		echo ' scheme_' . esc_attr( $algenix_scheme );
	}
	echo ' front_page_section_paddings_' . esc_attr( algenix_get_theme_option( 'front_page_contacts_paddings' ) );
	if ( algenix_get_theme_option( 'front_page_contacts_stack' ) ) {
		echo ' sc_stack_section_on';
	}
?>"
		<?php
		$algenix_css      = '';
		$algenix_bg_image = algenix_get_theme_option( 'front_page_contacts_bg_image' );
		if ( ! empty( $algenix_bg_image ) ) {
			$algenix_css .= 'background-image: url(' . esc_url( algenix_get_attachment_url( $algenix_bg_image ) ) . ');';
		}
		if ( ! empty( $algenix_css ) ) {
			echo ' style="' . esc_attr( $algenix_css ) . '"';
		}
		?>
>
<?php
	// Add anchor
	$algenix_anchor_icon = algenix_get_theme_option( 'front_page_contacts_anchor_icon' );
	$algenix_anchor_text = algenix_get_theme_option( 'front_page_contacts_anchor_text' );
if ( ( ! empty( $algenix_anchor_icon ) || ! empty( $algenix_anchor_text ) ) && shortcode_exists( 'trx_sc_anchor' ) ) {
	echo do_shortcode(
		'[trx_sc_anchor id="front_page_section_contacts"'
									. ( ! empty( $algenix_anchor_icon ) ? ' icon="' . esc_attr( $algenix_anchor_icon ) . '"' : '' )
									. ( ! empty( $algenix_anchor_text ) ? ' title="' . esc_attr( $algenix_anchor_text ) . '"' : '' )
									. ']'
	);
}
?>
	<div class="front_page_section_inner front_page_section_contacts_inner
	<?php
	if ( algenix_get_theme_option( 'front_page_contacts_fullheight' ) ) {
		echo ' algenix-full-height sc_layouts_flex sc_layouts_columns_middle';
	}
	?>
			"
			<?php
			$algenix_css      = '';
			$algenix_bg_mask  = algenix_get_theme_option( 'front_page_contacts_bg_mask' );
			$algenix_bg_color_type = algenix_get_theme_option( 'front_page_contacts_bg_color_type' );
			if ( 'custom' == $algenix_bg_color_type ) {
				$algenix_bg_color = algenix_get_theme_option( 'front_page_contacts_bg_color' );
			} elseif ( 'scheme_bg_color' == $algenix_bg_color_type ) {
				$algenix_bg_color = algenix_get_scheme_color( 'bg_color', $algenix_scheme );
			} else {
				$algenix_bg_color = '';
			}
			if ( ! empty( $algenix_bg_color ) && $algenix_bg_mask > 0 ) {
				$algenix_css .= 'background-color: ' . esc_attr(
					1 == $algenix_bg_mask ? $algenix_bg_color : algenix_hex2rgba( $algenix_bg_color, $algenix_bg_mask )
				) . ';';
			}
			if ( ! empty( $algenix_css ) ) {
				echo ' style="' . esc_attr( $algenix_css ) . '"';
			}
			?>
	>
		<div class="front_page_section_content_wrap front_page_section_contacts_content_wrap content_wrap">
			<?php

			// Title and description
			$algenix_caption     = algenix_get_theme_option( 'front_page_contacts_caption' );
			$algenix_description = algenix_get_theme_option( 'front_page_contacts_description' );
			if ( ! empty( $algenix_caption ) || ! empty( $algenix_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				// Caption
				if ( ! empty( $algenix_caption ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					?>
					<h2 class="front_page_section_caption front_page_section_contacts_caption front_page_block_<?php echo ! empty( $algenix_caption ) ? 'filled' : 'empty'; ?>">
					<?php
						echo wp_kses( $algenix_caption, 'algenix_kses_content' );
					?>
					</h2>
					<?php
				}

				// Description
				if ( ! empty( $algenix_description ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
					?>
					<div class="front_page_section_description front_page_section_contacts_description front_page_block_<?php echo ! empty( $algenix_description ) ? 'filled' : 'empty'; ?>">
					<?php
						echo wp_kses( wpautop( $algenix_description ), 'algenix_kses_content' );
					?>
					</div>
					<?php
				}
			}

			// Content (text)
			$algenix_content = algenix_get_theme_option( 'front_page_contacts_content' );
			$algenix_layout  = algenix_get_theme_option( 'front_page_contacts_layout' );
			if ( 'columns' == $algenix_layout && ( ! empty( $algenix_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				<div class="front_page_section_columns front_page_section_contacts_columns columns_wrap">
					<div class="column-1_3">
				<?php
			}

			if ( ( ! empty( $algenix_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				<div class="front_page_section_content front_page_section_contacts_content front_page_block_<?php echo ! empty( $algenix_content ) ? 'filled' : 'empty'; ?>">
					<?php
					echo wp_kses( $algenix_content, 'algenix_kses_content' );
					?>
				</div>
				<?php
			}

			if ( 'columns' == $algenix_layout && ( ! empty( $algenix_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				</div><div class="column-2_3">
				<?php
			}

			// Shortcode output
			$algenix_sc = algenix_get_theme_option( 'front_page_contacts_shortcode' );
			if ( ! empty( $algenix_sc ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) {
				?>
				<div class="front_page_section_output front_page_section_contacts_output front_page_block_<?php echo ! empty( $algenix_sc ) ? 'filled' : 'empty'; ?>">
					<?php
					algenix_show_layout( do_shortcode( $algenix_sc ) );
					?>
				</div>
				<?php
			}

			if ( 'columns' == $algenix_layout && ( ! empty( $algenix_content ) || ( current_user_can( 'edit_theme_options' ) && is_customize_preview() ) ) ) {
				?>
				</div></div>
				<?php
			}
			?>

		</div>
	</div>
</div>
