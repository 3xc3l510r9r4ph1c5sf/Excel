<?php
/**
 * The template to display Admin notices
 *
 * @package ALGENIX
 * @since ALGENIX 1.0.64
 */

$algenix_skins_url  = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$algenix_skins_args = get_query_var( 'algenix_skins_notice_args' );
?>
<div class="algenix_admin_notice algenix_skins_notice notice notice-info is-dismissible" data-notice="skins">
	<?php
	// Theme image
	$algenix_theme_img = algenix_get_file_url( 'screenshot.jpg' );
	if ( '' != $algenix_theme_img ) {
		?>
		<div class="algenix_notice_image"><img src="<?php echo esc_url( $algenix_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'algenix' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="algenix_notice_title">
		<?php esc_html_e( 'New skins are available', 'algenix' ); ?>
	</h3>
	<?php

	// Description
	$algenix_total      = $algenix_skins_args['update'];	// Store value to the separate variable to avoid warnings from ThemeCheck plugin!
	$algenix_skins_msg  = $algenix_total > 0
							// Translators: Add new skins number
							? '<strong>' . sprintf( _n( '%d new version', '%d new versions', $algenix_total, 'algenix' ), $algenix_total ) . '</strong>'
							: '';
	$algenix_total      = $algenix_skins_args['free'];
	$algenix_skins_msg .= $algenix_total > 0
							? ( ! empty( $algenix_skins_msg ) ? ' ' . esc_html__( 'and', 'algenix' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d free skin', '%d free skins', $algenix_total, 'algenix' ), $algenix_total ) . '</strong>'
							: '';
	$algenix_total      = $algenix_skins_args['pay'];
	$algenix_skins_msg .= $algenix_skins_args['pay'] > 0
							? ( ! empty( $algenix_skins_msg ) ? ' ' . esc_html__( 'and', 'algenix' ) . ' ' : '' )
								// Translators: Add new skins number
								. '<strong>' . sprintf( _n( '%d paid skin', '%d paid skins', $algenix_total, 'algenix' ), $algenix_total ) . '</strong>'
							: '';
	?>
	<div class="algenix_notice_text">
		<p>
			<?php
			// Translators: Add new skins info
			echo wp_kses_data( sprintf( __( "We are pleased to announce that %s are available for your theme", 'algenix' ), $algenix_skins_msg ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="algenix_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $algenix_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			// Translators: Add theme name
			esc_html_e( 'Go to Skins manager', 'algenix' );
			?>
		</a>
	</div>
</div>
