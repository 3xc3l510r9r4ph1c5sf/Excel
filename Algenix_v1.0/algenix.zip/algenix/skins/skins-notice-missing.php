<?php
/**
 * The template to display Admin notices
 *
 * @package ALGENIX
 * @since ALGENIX 1.98.0
 */

$algenix_skins_url   = get_admin_url( null, 'admin.php?page=trx_addons_theme_panel#trx_addons_theme_panel_section_skins' );
$algenix_active_skin = algenix_skins_get_active_skin_name();
?>
<div class="algenix_admin_notice algenix_skins_notice notice notice-error">
	<?php
	// Theme image
	$algenix_theme_img = algenix_get_file_url( 'screenshot.jpg' );
	if ( '' != $algenix_theme_img ) {
		?>
		<div class="algenix_notice_image"><img src="<?php echo esc_url( $algenix_theme_img ); ?>" alt="<?php esc_attr_e( 'Theme screenshot', 'algenix' ); ?>"></div>
		<?php
	}

	// Title
	?>
	<h3 class="algenix_notice_title">
		<?php esc_html_e( 'Active skin is missing!', 'algenix' ); ?>
	</h3>
	<div class="algenix_notice_text">
		<p>
			<?php
			// Translators: Add a current skin name to the message
			echo wp_kses_data( sprintf( __( "Your active skin <b>'%s'</b> is missing. Usually this happens when the theme is updated directly through the server or FTP.", 'algenix' ), ucfirst( $algenix_active_skin ) ) );
			?>
		</p>
		<p>
			<?php
			echo wp_kses_data( __( "Please use only <b>'ThemeREX Updater v.1.6.0+'</b> plugin for your future updates.", 'algenix' ) );
			?>
		</p>
		<p>
			<?php
			echo wp_kses_data( __( "But no worries! You can re-download the skin via 'Skins Manager' ( Theme Panel - Theme Dashboard - Skins ).", 'algenix' ) );
			?>
		</p>
	</div>
	<?php

	// Buttons
	?>
	<div class="algenix_notice_buttons">
		<?php
		// Link to the theme dashboard page
		?>
		<a href="<?php echo esc_url( $algenix_skins_url ); ?>" class="button button-primary"><i class="dashicons dashicons-update"></i> 
			<?php
			// Translators: Add theme name
			esc_html_e( 'Go to Skins manager', 'algenix' );
			?>
		</a>
	</div>
</div>
