<?php
/**
 * The template to display the copyright info in the footer
 *
 * @package ALGENIX
 * @since ALGENIX 1.0.10
 */

// Copyright area
?> 
<div class="footer_copyright_wrap">
	<div class="footer_copyright_inner">
		<div class="content_wrap">
			<div class="copyright_text">
				<?php
					$algenix_copyright = algenix_get_theme_option( 'copyright' );
					if ( ! empty( $algenix_copyright ) ) {
						// Replace {{Y}} or {Y} with the current year
						$algenix_copyright = str_replace( array( '{{Y}}', '{Y}' ), date( 'Y' ), $algenix_copyright );
						// Replace {{...}} and ((...)) on the <i>...</i> and <b>...</b>
						$algenix_copyright = algenix_prepare_macros( $algenix_copyright );
						// Display copyright
						echo wp_kses( nl2br( $algenix_copyright ), 'algenix_kses_content' );
					}
				?>
			</div>
		</div>
	</div>
</div>