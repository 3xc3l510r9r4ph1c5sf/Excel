<?php
/**
 * The Classic template to display the content
 *
 * Used for index/archive/search.
 *
 * @package ALGENIX
 * @since ALGENIX 1.0
 */

$algenix_template_args = get_query_var( 'algenix_template_args' );

if ( is_array( $algenix_template_args ) ) {
	$algenix_columns       = empty( $algenix_template_args['columns'] ) ? 1 : max( 1, $algenix_template_args['columns'] );
	$algenix_blog_style    = array( $algenix_template_args['type'], $algenix_columns );
	$algenix_columns_class = algenix_get_column_class( 1, $algenix_columns, ! empty( $algenix_template_args['columns_tablet']) ? $algenix_template_args['columns_tablet'] : '', ! empty($algenix_template_args['columns_mobile']) ? $algenix_template_args['columns_mobile'] : '' );
} else {
	$algenix_template_args = array();
	$algenix_blog_style    = explode( '_', algenix_get_theme_option( 'blog_style' ) );
	$algenix_columns       = empty( $algenix_blog_style[1] ) ? 1 : max( 1, $algenix_blog_style[1] );
	$algenix_columns_class = algenix_get_column_class( 1, $algenix_columns );
}
$algenix_expanded   = ! algenix_sidebar_present() && algenix_get_theme_option( 'expand_content' ) == 'expand';

$algenix_post_format = get_post_format();
$algenix_post_format = empty( $algenix_post_format ) ? 'standard' : str_replace( 'post-format-', '', $algenix_post_format );

?><div class="<?php
	if ( ! empty( $algenix_template_args['slider'] ) ) {
		echo ' slider-slide swiper-slide';
	} else {
		echo ( algenix_is_blog_style_use_masonry( $algenix_blog_style[0] )
			? 'masonry_item masonry_item-1_' . esc_attr( $algenix_columns )
			: esc_attr( $algenix_columns_class )
			);
	}
?>"><article id="post-<?php the_ID(); ?>" data-post-id="<?php the_ID(); ?>"
	<?php
	post_class(
		'post_item post_item_container post_format_' . esc_attr( $algenix_post_format )
				. ' post_layout_classic post_layout_classic_' . esc_attr( $algenix_columns )
				. ' post_layout_' . esc_attr( $algenix_blog_style[0] )
				. ' post_layout_' . esc_attr( $algenix_blog_style[0] ) . '_' . esc_attr( $algenix_columns )
	);
	algenix_add_blog_animation( $algenix_template_args );
	?>
>
	<?php

	// Sticky label
	if ( is_sticky() && ! is_paged() ) {
		?><span class="post_label label_sticky"></span><?php
	}

	// Featured image
	$algenix_hover      = ! empty( $algenix_template_args['hover'] ) && ! algenix_is_inherit( $algenix_template_args['hover'] )
							? $algenix_template_args['hover']
							: algenix_get_theme_option( 'image_hover' );

	$algenix_components = ! empty( $algenix_template_args['meta_parts'] )
							? ( is_array( $algenix_template_args['meta_parts'] )
								? $algenix_template_args['meta_parts']
								: array_map( 'trim', explode( ',', $algenix_template_args['meta_parts'] ) )
								)
							: algenix_array_get_keys_by_value( algenix_get_theme_option( 'meta_parts' ) );

	algenix_show_post_featured( apply_filters( 'algenix_filter_args_featured',
		array(
			'thumb_size' => ! empty( $algenix_template_args['thumb_size'] )
								? $algenix_template_args['thumb_size']
								: algenix_get_thumb_size(
									strpos( algenix_get_theme_option( 'body_style' ), 'full' ) !== false
										? ( $algenix_columns > 2 ? 'big' : 'full' )
										: ( $algenix_columns > 2
											? 'med'
											: ( $algenix_expanded || $algenix_columns == 1 ? 
												( $algenix_expanded && $algenix_columns == 1 ? 'huge' : 'big' ) 
												: 'med' 
												)
											)												
								),
			'hover'      => $algenix_hover,
			'meta_parts' => $algenix_components,
			'no_links'   => ! empty( $algenix_template_args['no_links'] ),
		),
		'content-classic',
		$algenix_template_args
	) );

	// Title and post meta
	$algenix_show_title = get_the_title() != '';
	$algenix_show_meta  = count( $algenix_components ) > 0;

	if ( $algenix_show_title ) {
		?><div class="post_header entry-header"><?php
			// Categories
			if ( apply_filters( 'algenix_filter_show_blog_categories', $algenix_show_meta && in_array( 'categories', $algenix_components ), array( 'categories' ), 'classic' ) ) {
				do_action( 'algenix_action_before_post_category' );
				?><div class="post_category"><?php
					algenix_show_post_meta( apply_filters(
														'algenix_filter_post_meta_args',
														array(
															'components' => 'categories',
															'seo'        => false,
															'echo'       => true,
															),
														'hover_' . $algenix_hover, 1
														)
										);
				?></div><?php
				$algenix_components = algenix_array_delete_by_value( $algenix_components, 'categories' );
				do_action( 'algenix_action_after_post_category' );
			}
			// Post title
			if ( apply_filters( 'algenix_filter_show_blog_title', true, 'classic' ) ) {
				do_action( 'algenix_action_before_post_title' );
				if ( empty( $algenix_template_args['no_links'] ) ) {
					the_title( sprintf( '<h3 class="post_title entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h3>' );
				} else {
					the_title( '<h3 class="post_title entry-title">', '</h3>' );
				}
				do_action( 'algenix_action_after_post_title' );
			}
		?></div><?php
	}
	
	// Post meta
	if ( apply_filters( 'algenix_filter_show_blog_meta', $algenix_show_meta, $algenix_components, 'classic' ) ) {
		if ( count( $algenix_components ) > 0 ) {
			do_action( 'algenix_action_before_post_meta' );
			algenix_show_post_meta(
				apply_filters(
					'algenix_filter_post_meta_args', array(
						'components' => join( ',', $algenix_components ),
						'seo'        => false,
						'echo'       => true,
						'author_avatar' => false,
					), $algenix_blog_style[0], $algenix_columns
				)
			);
			do_action( 'algenix_action_after_post_meta' );
		}
	}

	// Post content
	ob_start();
	if ( apply_filters( 'algenix_filter_show_blog_excerpt', ( ! isset( $algenix_template_args['hide_excerpt'] ) || (int)$algenix_template_args['hide_excerpt'] == 0 ) && (int)algenix_get_theme_option( 'excerpt_length' ) > 0, 'classic' ) ) {
		algenix_show_post_content( $algenix_template_args, '<div class="post_content_inner">', '</div>' );
	}
	$algenix_content = ob_get_contents();
	ob_end_clean();

	algenix_show_layout( $algenix_content, '<div class="post_content entry-content">', '</div>' );

		
	// More button
	if ( apply_filters( 'algenix_filter_show_blog_readmore', ! $algenix_show_title || ! empty( $algenix_template_args['more_button'] ), 'classic' ) ) {
		if ( empty( $algenix_template_args['no_links'] ) ) {
			do_action( 'algenix_action_before_post_readmore' );
			algenix_show_post_more_link( $algenix_template_args, '<p>', '</p>' );
			do_action( 'algenix_action_after_post_readmore' );
		}
	}

	?>

</article></div><?php
// Need opening PHP-tag above, because <div> is a inline-block element (used as column)!
