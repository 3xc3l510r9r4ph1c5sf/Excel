<?php
/**
 * The template 'Style 2' to displaying related posts
 *
 * @package ALGENIX
 * @since ALGENIX 1.0
 */

$algenix_link        = get_permalink();
$algenix_post_format = get_post_format();
$algenix_post_format = empty( $algenix_post_format ) ? 'standard' : str_replace( 'post-format-', '', $algenix_post_format );

?><div id="post-<?php the_ID(); ?>" <?php post_class( 'related_item post_format_' . esc_attr( $algenix_post_format ) ); ?> data-post-id="<?php the_ID(); ?>">
	<?php
	algenix_show_post_featured(
		array(
			'thumb_size' => apply_filters( 'algenix_filter_related_thumb_size', algenix_get_thumb_size(
				(int) algenix_get_theme_option( 'related_posts' ) == 1 || (int) algenix_get_theme_option( 'related_columns' ) == 1 ? 'full' : 'big' )
			),
		)
	);
	?>
	<div class="post_header entry-header">
		<?php
		if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
			algenix_show_post_meta(
				array(
					'components' => 'categories',
					'class'      => 'post_meta_categories',
				)
			);	
		}
		?>
		<h4 class="post_title entry-title"><a href="<?php echo esc_url( $algenix_link ); ?>"><?php
			if ( '' == get_the_title() ) {
				esc_html_e( 'No title', 'algenix' );
			} else {
				the_title();
			}
		?></a></h4>
		<?php
		if ( in_array( get_post_type(), array( 'post', 'attachment' ) ) ) {
			algenix_show_post_meta(
				array(
					'components' => 'date, comments',
					'class'      => 'post_meta_info',
				)
			);	
		}
		?>
	</div>
</div>
