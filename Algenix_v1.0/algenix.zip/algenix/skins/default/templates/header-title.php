<?php
/**
 * The template to display the page title and breadcrumbs
 *
 * @package ALGENIX
 * @since ALGENIX 1.0
 */

// Page (category, tag, archive, author) title

if ( algenix_need_page_title() ) {
	algenix_sc_layouts_showed( 'title', true );
	?>
	<div class="top_panel_title sc_layouts_row">
		<div class="content_wrap">
			<div class="sc_layouts_column sc_layouts_column_align_center">
				<div class="sc_layouts_item">
					<div class="sc_layouts_title sc_align_center">
						<?php
						// Blog/Page title
						?>
						<div class="sc_layouts_title_title">
							<?php
							$algenix_blog_title           = algenix_get_blog_title();
							$algenix_blog_title_text      = '';
							$algenix_blog_title_class     = '';
							$algenix_blog_title_link      = '';
							$algenix_blog_title_link_text = '';
							if ( is_array( $algenix_blog_title ) ) {
								$algenix_blog_title_text      = $algenix_blog_title['text'];
								$algenix_blog_title_class     = ! empty( $algenix_blog_title['class'] ) ? ' ' . $algenix_blog_title['class'] : '';
								$algenix_blog_title_link      = ! empty( $algenix_blog_title['link'] ) ? $algenix_blog_title['link'] : '';
								$algenix_blog_title_link_text = ! empty( $algenix_blog_title['link_text'] ) ? $algenix_blog_title['link_text'] : '';
							} else {
								$algenix_blog_title_text = $algenix_blog_title;
							}
							?>
							<h1 itemprop="headline" class="sc_layouts_title_caption<?php echo esc_attr( $algenix_blog_title_class ); ?>">
								<?php
								$algenix_top_icon = algenix_get_term_image_small();
								if ( ! empty( $algenix_top_icon ) ) {
									$algenix_attr = algenix_getimagesize( $algenix_top_icon );
									?>
									<img src="<?php echo esc_url( $algenix_top_icon ); ?>" alt="<?php esc_attr_e( 'Site icon', 'algenix' ); ?>"
										<?php
										if ( ! empty( $algenix_attr[3] ) ) {
											algenix_show_layout( $algenix_attr[3] );
										}
										?>
									>
									<?php
								}
								echo wp_kses_data( $algenix_blog_title_text );
								?>
							</h1>
							<?php
							if ( ! empty( $algenix_blog_title_link ) && ! empty( $algenix_blog_title_link_text ) ) {
								?>
								<a href="<?php echo esc_url( $algenix_blog_title_link ); ?>" class="theme_button sc_layouts_title_link"><?php echo esc_html( $algenix_blog_title_link_text ); ?></a>
								<?php
							}

							// Category/Tag description
							if ( ! is_paged() && ( is_category() || is_tag() || is_tax() ) ) {
								the_archive_description( '<div class="sc_layouts_title_description">', '</div>' );
							}

							?>
						</div>
						<?php

						// Breadcrumbs
						ob_start();
						do_action( 'algenix_action_breadcrumbs' );
						$algenix_breadcrumbs = ob_get_contents();
						ob_end_clean();
						algenix_show_layout( $algenix_breadcrumbs, '<div class="sc_layouts_title_breadcrumbs">', '</div>' );
						?>
					</div>
				</div>
			</div>
		</div>
	</div>
	<?php
}
