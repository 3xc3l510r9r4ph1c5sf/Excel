<?php
/**
 * The template to display default site footer
 *
 * @package ALGENIX
 * @since ALGENIX 1.0.10
 */

$algenix_footer_id = algenix_get_custom_footer_id();
$algenix_footer_meta = algenix_get_custom_layout_meta( $algenix_footer_id );
if ( ! empty( $algenix_footer_meta['margin'] ) ) {
	algenix_add_inline_css( sprintf( '.page_content_wrap{padding-bottom:%s}', esc_attr( algenix_prepare_css_value( $algenix_footer_meta['margin'] ) ) ) );
}
?>
<footer class="footer_wrap footer_custom footer_custom_<?php echo esc_attr( $algenix_footer_id ); ?> footer_custom_<?php echo esc_attr( sanitize_title( get_the_title( $algenix_footer_id ) ) ); ?>">
	<?php
	// Custom footer's layout
	do_action( 'algenix_action_show_layout', $algenix_footer_id );
	?>
</footer>