<?php
/**
 * The template to display custom header from the ThemeREX Addons Layouts
 *
 * @package ALGENIX
 * @since ALGENIX 1.0.06
 */

$algenix_header_css   = '';
$algenix_header_image = get_header_image();
if ( ! empty( $algenix_header_image ) && algenix_trx_addons_featured_image_override( algenix_is_singular() || algenix_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$algenix_header_image = algenix_get_current_mode_image( $algenix_header_image );
}

$algenix_header_id = algenix_get_custom_header_id();
$algenix_header_meta = algenix_get_custom_layout_meta( $algenix_header_id );
if ( ! empty( $algenix_header_meta['margin'] ) ) {
	algenix_add_inline_css( sprintf( '.page_content_wrap{padding-top:%s}', esc_attr( algenix_prepare_css_value( $algenix_header_meta['margin'] ) ) ) );
	algenix_storage_set( 'custom_header_margin', algenix_prepare_css_value( $algenix_header_meta['margin'] ) );
}

?><header class="top_panel top_panel_custom top_panel_custom_<?php echo esc_attr( $algenix_header_id ); ?> top_panel_custom_<?php echo esc_attr( sanitize_title( get_the_title( $algenix_header_id ) ) ); ?>
				<?php
				echo ! empty( $algenix_header_image )
					? ' with_bg_image'
					: ' without_bg_image';
				if ( '' != $algenix_header_image ) {
					echo ' ' . esc_attr( algenix_add_inline_css_class( 'background-image: url(' . esc_url( $algenix_header_image ) . ');' ) );
				}
				if ( algenix_is_single() && has_post_thumbnail() ) {
					echo ' with_featured_image';
				}
				?>
">
	<?php

	// Custom header's layout
	do_action( 'algenix_action_show_layout', $algenix_header_id );

	?>
</header>
