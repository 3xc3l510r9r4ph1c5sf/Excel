<?php
/**
 * The template to display default site header
 *
 * @package ALGENIX
 * @since ALGENIX 1.0
 */

$algenix_header_css   = '';
$algenix_header_image = get_header_image();
$algenix_header_video = algenix_get_header_video();
if ( ! empty( $algenix_header_image ) && algenix_trx_addons_featured_image_override( algenix_is_singular() || algenix_storage_isset( 'blog_archive' ) || is_category() ) ) {
	$algenix_header_image = algenix_get_current_mode_image( $algenix_header_image );
}
?><header class="top_panel top_panel_default
	<?php
	echo ! empty( $algenix_header_image ) || ! empty( $algenix_header_video ) ? ' with_bg_image' : ' without_bg_image';
	if ( '' != $algenix_header_video ) {
		echo ' with_bg_video';
	}
	if ( '' != $algenix_header_image ) {
		echo ' ' . esc_attr( algenix_add_inline_css_class( 'background-image: url(' . esc_url( $algenix_header_image ) . ');' ) );
	}
	if ( algenix_is_singular() && has_post_thumbnail() ) {
		echo ' with_featured_image';
	}
	?>
">
	<?php

	// Background video
	if ( ! empty( $algenix_header_video ) ) {
		get_template_part( apply_filters( 'algenix_filter_get_template_part', 'templates/header-video' ) );
	}

	// Main menu
	get_template_part( apply_filters( 'algenix_filter_get_template_part', 'templates/header-navi' ) );

	// Page title and breadcrumbs area
	if ( ! algenix_is_single() ) {
		get_template_part( apply_filters( 'algenix_filter_get_template_part', 'templates/header-title' ) );
	}
	?>
</header>
