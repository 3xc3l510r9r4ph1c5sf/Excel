<?php
/**
 * The template to display the logo or the site name and the slogan in the Header
 *
 * @package ALGENIX
 * @since ALGENIX 1.0
 */

$algenix_args = get_query_var( 'algenix_logo_args' );

// Site logo
$algenix_logo_type   = isset( $algenix_args['type'] ) ? $algenix_args['type'] : '';
$algenix_logo_image  = algenix_get_logo_image( $algenix_logo_type );
$algenix_logo_text   = algenix_is_on( algenix_get_theme_option( 'logo_text' ) ) ? get_bloginfo( 'name' ) : '';
$algenix_logo_slogan = get_bloginfo( 'description', 'display' );
if ( ! empty( $algenix_logo_image['logo'] ) || ! empty( $algenix_logo_text ) ) {
	?><a class="sc_layouts_logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
		<?php
		if ( ! empty( $algenix_logo_image['logo'] ) ) {
			if ( empty( $algenix_logo_type ) && function_exists( 'the_custom_logo' ) && is_numeric( $algenix_logo_image['logo'] ) && (int) $algenix_logo_image['logo'] > 0 ) {
				the_custom_logo();
			} else {
				$algenix_attr = algenix_getimagesize( $algenix_logo_image['logo'] );
				echo '<img src="' . esc_url( $algenix_logo_image['logo'] ) . '"'
						. ( ! empty( $algenix_logo_image['logo_retina'] ) ? ' srcset="' . esc_url( $algenix_logo_image['logo_retina'] ) . ' 2x"' : '' )
						. ' alt="' . esc_attr( $algenix_logo_text ) . '"'
						. ( ! empty( $algenix_attr[3] ) ? ' ' . wp_kses_data( $algenix_attr[3] ) : '' )
						. '>';
			}
		} else {
			algenix_show_layout( algenix_prepare_macros( $algenix_logo_text ), '<span class="logo_text">', '</span>' );
			algenix_show_layout( algenix_prepare_macros( $algenix_logo_slogan ), '<span class="logo_slogan">', '</span>' );
		}
		?>
	</a>
	<?php
}
