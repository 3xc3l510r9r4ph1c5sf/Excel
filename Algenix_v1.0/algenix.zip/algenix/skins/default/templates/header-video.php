<?php
/**
 * The template to display the background video in the header
 *
 * @package ALGENIX
 * @since ALGENIX 1.0.14
 */
$algenix_header_video = algenix_get_header_video();
$algenix_embed_video  = '';
if ( ! empty( $algenix_header_video ) && ! algenix_is_from_uploads( $algenix_header_video ) ) {
	if ( algenix_is_youtube_url( $algenix_header_video ) && preg_match( '/[=\/]([^=\/]*)$/', $algenix_header_video, $matches ) && ! empty( $matches[1] ) ) {
		?><div id="background_video" data-youtube-code="<?php echo esc_attr( $matches[1] ); ?>"></div>
		<?php
	} else {
		?>
		<div id="background_video"><?php algenix_show_layout( algenix_get_embed_video( $algenix_header_video ) ); ?></div>
		<?php
	}
}