<?php
/**
 * Required plugins
 *
 * @package ALGENIX
 * @since ALGENIX 1.76.0
 */

// THEME-SUPPORTED PLUGINS
// If plugin not need - remove its settings from next array
//----------------------------------------------------------
if ( ! function_exists( 'algenix_skin_required_plugins' ) ) {
	add_action( 'after_setup_theme', 'algenix_skin_required_plugins', -1 );
	function algenix_skin_required_plugins() {
		$algenix_theme_required_plugins_groups = array(
	'core'          => esc_html__( 'Core', 'algenix' ),
	'page_builders' => esc_html__( 'Page Builders', 'algenix' ),
	'ecommerce'     => esc_html__( 'E-Commerce & Donations', 'algenix' ),
	'socials'       => esc_html__( 'Socials and Communities', 'algenix' ),
	'events'        => esc_html__( 'Events and Appointments', 'algenix' ),
	'content'       => esc_html__( 'Content', 'algenix' ),
	'other'         => esc_html__( 'Other', 'algenix' ),
		);
		$algenix_theme_required_plugins        = array(
	// Core
	'trx_addons'                 => array(
		'title'       => esc_html__( 'ThemeREX Addons', 'algenix' ),
		'description' => esc_html__( "Will allow you to install recommended plugins, demo content, and improve the theme's functionality overall with multiple theme options", 'algenix' ),
		'required'    => true, // Check this plugin in the list on load Theme Dashboard
		'logo'        => 'trx_addons.png',
		'group'       => $algenix_theme_required_plugins_groups['core'],
	),
	// Page Builders
	'elementor'                  => array(
		'title'       => esc_html__( 'Elementor', 'algenix' ),
		'description' => esc_html__( "Is a beautiful PageBuilder, even the free version of which allows you to create great pages using a variety of modules.", 'algenix' ),
		'required'    => false, // Leave this plugin unchecked on load Theme Dashboard
		'logo'        => 'elementor.png',
		'group'       => $algenix_theme_required_plugins_groups['page_builders'],
	),
	'gutenberg'                  => array(
		'title'       => esc_html__( 'Gutenberg', 'algenix' ),
		'description' => esc_html__( "It's a posts editor coming in place of the classic TinyMCE. Can be installed and used in parallel with Elementor", 'algenix' ),
		'required'    => false,
		'install'     => false, // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
		'logo'        => 'gutenberg.png',
		'group'       => $algenix_theme_required_plugins_groups['page_builders'],
	),
	// Content
	'sitepress-multilingual-cms' => array(
		'title'       => esc_html__( 'WPML - Sitepress Multilingual CMS', 'algenix' ),
		'description' => esc_html__( "Allows you to make your website multilingual", 'algenix' ),
		'required'    => false,
		'install'     => false, // Do not offer installation of the plugin in the Theme Dashboard and TGMPA
		'logo'        => 'sitepress-multilingual-cms.png',
		'group'       => $algenix_theme_required_plugins_groups['content'],
	),
	'metform'             => array(
		'title'       => esc_html__( 'MetForm', 'algenix' ),
		'description' => esc_html__( "Contact Form, Survey, Quiz, & Custom Form Builder for Elementor", 'algenix' ),
		'required'    => false,
		'logo'        => 'metform.png',
		'group'       => $algenix_theme_required_plugins_groups['content'],
	),
	// Other
	'trx_updater'                => array(
		'title'       => esc_html__( 'ThemeREX Updater', 'algenix' ),
		'description' => esc_html__( "Update theme and theme-specific plugins from developer's upgrade server.", 'algenix' ),
		'required'    => false,
		'logo'        => 'trx_updater.png',
		'group'       => $algenix_theme_required_plugins_groups['other'],
	)
		);

		if ( ALGENIX_THEME_FREE ) {
	unset( $algenix_theme_required_plugins['sitepress-multilingual-cms'] );
	unset( $algenix_theme_required_plugins['trx_updater'] );
		}

		// Add plugins list to the global storage
		algenix_storage_set( 'required_plugins', $algenix_theme_required_plugins );
	}
}
