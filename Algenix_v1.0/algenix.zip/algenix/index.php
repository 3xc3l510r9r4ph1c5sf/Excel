<?php
/**
 * The main template file.
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 * Learn more: //codex.wordpress.org/Template_Hierarchy
 *
 * @package ALGENIX
 * @since ALGENIX 1.0
 */

$algenix_template = apply_filters( 'algenix_filter_get_template_part', algenix_blog_archive_get_template() );

if ( ! empty( $algenix_template ) && 'index' != $algenix_template ) {

	get_template_part( $algenix_template );

} else {

	algenix_storage_set( 'blog_archive', true );

	get_header();

	if ( have_posts() ) {

		// Query params
		$algenix_stickies   = is_home()
								|| ( in_array( algenix_get_theme_option( 'post_type' ), array( '', 'post' ) )
									&& (int) algenix_get_theme_option( 'parent_cat' ) == 0
									)
										? get_option( 'sticky_posts' )
										: false;
		$algenix_post_type  = algenix_get_theme_option( 'post_type' );
		$algenix_args       = array(
								'blog_style'     => algenix_get_theme_option( 'blog_style' ),
								'post_type'      => $algenix_post_type,
								'taxonomy'       => algenix_get_post_type_taxonomy( $algenix_post_type ),
								'parent_cat'     => algenix_get_theme_option( 'parent_cat' ),
								'posts_per_page' => algenix_get_theme_option( 'posts_per_page' ),
								'sticky'         => algenix_get_theme_option( 'sticky_style', 'inherit' ) == 'columns'
															&& is_array( $algenix_stickies )
															&& count( $algenix_stickies ) > 0
															&& get_query_var( 'paged' ) < 1
								);

		algenix_blog_archive_start();

		do_action( 'algenix_action_blog_archive_start' );

		if ( is_author() ) {
			do_action( 'algenix_action_before_page_author' );
			get_template_part( apply_filters( 'algenix_filter_get_template_part', 'templates/author-page' ) );
			do_action( 'algenix_action_after_page_author' );
		}

		if ( algenix_get_theme_option( 'show_filters', 0 ) ) {
			do_action( 'algenix_action_before_page_filters' );
			algenix_show_filters( $algenix_args );
			do_action( 'algenix_action_after_page_filters' );
		} else {
			do_action( 'algenix_action_before_page_posts' );
			algenix_show_posts( array_merge( $algenix_args, array( 'cat' => $algenix_args['parent_cat'] ) ) );
			do_action( 'algenix_action_after_page_posts' );
		}

		do_action( 'algenix_action_blog_archive_end' );

		algenix_blog_archive_end();

	} else {

		if ( is_search() ) {
			get_template_part( apply_filters( 'algenix_filter_get_template_part', 'templates/content', 'none-search' ), 'none-search' );
		} else {
			get_template_part( apply_filters( 'algenix_filter_get_template_part', 'templates/content', 'none-archive' ), 'none-archive' );
		}
	}

	get_footer();
}
